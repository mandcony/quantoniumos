"""QuantoniumOS auth package."""
