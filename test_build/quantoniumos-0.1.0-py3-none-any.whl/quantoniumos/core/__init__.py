"""QuantoniumOS core package."""
