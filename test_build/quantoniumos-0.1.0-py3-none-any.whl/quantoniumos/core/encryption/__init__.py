"""QuantoniumOS encryption package."""
