// services/gates.js
import { SymbolicAmplitude } from './SymbolicAmplitude';

export class HGate {
  constructor() {
    this.name = 'H';
    this.matrix = [
      [
        (s) => SymbolicAmplitude.fromString(`(1/sqrt(2))*${s}`),
        (s) => SymbolicAmplitude.fromString(`(1/sqrt(2))*${s}`)
      ],
      [
        (s) => SymbolicAmplitude.fromString(`(1/sqrt(2))*${s}`),
        (s) => SymbolicAmplitude.fromString(`(-1/sqrt(2))*${s}`)
      ],
    ];
  }
}

export class XGate {
  constructor() {
    this.name = 'X';
    this.matrix = [
      [
        (s) => SymbolicAmplitude.fromString(`0*${s}`),
        (s) => SymbolicAmplitude.fromString(`1*${s}`)
      ],
      [
        (s) => SymbolicAmplitude.fromString(`1*${s}`),
        (s) => SymbolicAmplitude.fromString(`0*${s}`)
      ],
    ];
  }
}

// For advanced gates: Y, Z, S, T, CNOT(4x4), etc.
