export class Complex {
  constructor(real, imag) {
    this.real = real;
    this.imag = imag;
  }

  add(other) {
    return new Complex(this.real + other.real, this.imag + other.imag);
  }

  multiply(other) {
    // (a + bi)(c + di) = (ac - bd) + (ad + bc)i
    const re = this.real * other.real - this.imag * other.imag;
    const im = this.real * other.imag + this.imag * other.real;
    return new Complex(re, im);
  }

  toString() {
    const sign = this.imag >= 0 ? '+' : '';
    return `${this.real}${sign}${this.imag}i`;
  }
}