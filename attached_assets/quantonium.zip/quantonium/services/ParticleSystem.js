import * as THREE from 'three';

export const createParticleSystem = (numParticles, size, bounds, primaryColor, secondaryColor) => {
    const particles = new THREE.Group();
    const positions = [];
    const velocities = [];
    const lifeSpans = [];
      const initialSizes = [];
        const rotations = [];
  for (let i = 0; i < numParticles; i++) {
       const color = new THREE.Color(Math.random() > 0.5 ? primaryColor: secondaryColor);
      const geometry = new THREE.SphereGeometry(size, 5, 5);
      const material = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.4 });
          const sphere = new THREE.Mesh(geometry, material);
          particles.add(sphere)
        // random pos
      const x = (Math.random() - 0.5) * bounds.width;
        const y = (Math.random() - 0.5) * bounds.height;
      const z = (Math.random() - 0.5) * 10; // Add a z coordinate.

        // random direction
      const vx = (Math.random() - 0.5) * 0.1;
          const vy = (Math.random() - 0.5) * 0.1;
            const vz = (Math.random() - 0.5) * 0.1; // Add a z component.

        const lifeSpan = Math.random() * 50; // max lifespan 50 steps
          const initialSize = size;
           const rx = Math.random() * 0.1;
            const ry = Math.random() * 0.1;
             const rz = Math.random() * 0.1;


       positions.push({x, y, z});
       velocities.push({x:vx, y:vy, z:vz});
       lifeSpans.push(lifeSpan);
          initialSizes.push(initialSize);
          rotations.push({x:rx,y:ry, z:rz});
      }
   const animationID = UseRef(null);
      const tick = () => {
        if (animationID.current == null) return;
          for (let i = 0; i < numParticles; i++) {
            lifeSpans[i] -=1;
              if (lifeSpans[i] <= 0) {
              const x = (Math.random() - 0.5) * bounds.width;
              const y = (Math.random() - 0.5) * bounds.height;
              const z = (Math.random() - 0.5) * 10; // Add a z coordinate.

             const vx = (Math.random() - 0.5) * 0.1;
             const vy = (Math.random() - 0.5) * 0.1;
                const vz = (Math.random() - 0.5) * 0.1; // Add a z component.

              lifeSpans[i] = Math.random() * 50;
              positions[i] = {x,y,z};
             velocities[i] = {x:vx, y:vy, z:vz}

            }
         positions[i].x += velocities[i].x;
            positions[i].y += velocities[i].y;
              positions[i].z += velocities[i].z;


              particles.children[i].position.set(positions[i].x, positions[i].y, positions[i].z);
                 particles.children[i].rotation.x += rotations[i].x;
                  particles.children[i].rotation.y += rotations[i].y;
                   particles.children[i].rotation.z += rotations[i].z;
              const scale = 0.25 + lifeSpans[i]/50 * initialSizes[i] * 0.75;
              particles.children[i].scale.set(scale, scale, scale)

          }
      };

     const render = () => {
           if (animationID.current == null) {
               animationID.current = requestAnimationFrame(function animate() {
                tick();
                animationID.current = requestAnimationFrame(animate)
                })
            }

              return particles;
    };
      const start = () => {
        if (animationID.current == null) {
               animationID.current = requestAnimationFrame(function animate() {
                tick();
                animationID.current = requestAnimationFrame(animate)
                })
            }
    }
        const stop = () => {
            if (animationID.current) {
             cancelAnimationFrame(animationID.current);
                animationID.current = null;
             }
    }
      const dispose = () => {
         stop();
        particles.children.forEach(x => x.geometry.dispose());
          particles.children.forEach(x => x.material.dispose());
        particles.clear();
    }
    return { render, start, stop, dispose };
};