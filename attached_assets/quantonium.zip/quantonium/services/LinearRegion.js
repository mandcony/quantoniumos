// services/LinearRegion.js
export default class LinearRegion {
  constructor(points) {
    this.points = points;
    this.averageLength = this.computeAverageLength();
  }

  computeAverageLength() {
    if (this.points.length < 2) return 0;
    let sum = 0, count = 0;
    for (let i = 0; i < this.points.length - 1; i++) {
      const [x1, y1, z1] = this.points[i];
      const [x2, y2, z2] = this.points[i+1];
      const dist = Math.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2);
      sum += dist;
      count++;
    }
    return count > 0 ? sum / count : 0;
  }
}
