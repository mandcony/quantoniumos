// GeometryClasses.js
import * as math from 'mathjs';

export class Oscillator {
  constructor(frequency, amplitude, phase) {
    this.frequency = frequency;
    this.amplitude = amplitude;
    this.phase = phase;
    this.time = 0;
  }
  update(deltaTime) {
    this.time += deltaTime;
  }
  getAmplitudeValue() {
    return this.amplitude * Math.sin(2 * Math.PI * this.frequency * this.time + this.phase);
  }
}

export class LinearRegion {
  constructor(points) {
    this.points = points;
    this.averageLength = this.computeAverageLength();
  }
  computeAverageLength() {
    if (this.points.length < 2) return 0;
    let sum = 0, count = 0;
    for (let i=0; i<this.points.length-1; i++){
      const [x1,y1,z1] = this.points[i];
      const [x2,y2,z2] = this.points[i+1];
      const dist = Math.sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2);
      sum += dist; 
      count++;
    }
    return count > 0 ? sum / count : 0;
  }
}

export class GeometricContainer {
  constructor(id, vertices, transformations=[], materialProps={}) {
    this.id = id;
    this.vertices = vertices;
    this.transformations = transformations;
    this.data = null;
    this.linearRegions = [];
    this.resonantFrequencies = [];
    this.material = {
      youngsModulus: materialProps.youngsModulus || 1e9,
      density: materialProps.density || 2700,
    };
    // Attach an oscillator for demonstration
    this.oscillator = new Oscillator(1, 0.1, 0);
  }

  encodeData(d) {
    this.data = d;
  }
  getData() {
    return this.data;
  }
  addLinearRegion(lr) {
    this.linearRegions.push(lr);
  }
  calculateResonantFrequencies(dampFactor=0.1) {
    const out = [];
    for (let lr of this.linearRegions) {
      if (lr.averageLength > 0) {
        const freq = Math.sqrt(this.material.youngsModulus / (this.material.density * lr.averageLength)) 
                   * (1 - dampFactor);
        out.push(freq);
      } else {
        out.push(0);
      }
    }
    this.resonantFrequencies = out;
    return out;
  }
  checkResonance(freq, threshold=0.1) {
    for (let r of this.resonantFrequencies) {
      if (Math.abs(r - freq) <= threshold) return true;
    }
    return false;
  }
  applyAllTransformations() {
    let mat = math.identity(4);
    for (let t of this.transformations) {
      mat = math.multiply(mat, this._buildTransformMatrix(t));
    }
    this.vertices = this.vertices.map(([x,y,z]) => {
      const v = math.matrix([x,y,z,1]);
      const res = math.multiply(mat, v).toArray();
      return res.slice(0,3);
    });
  }
  _buildTransformMatrix(tr) {
    let M = math.identity(4);
    // rotation
    if (tr.rotation) {
      const { x=0, y=0, z=0 } = tr.rotation;
      const rx = math.matrix([
        [1,0,0,0],
        [0,Math.cos(x), -Math.sin(x),0],
        [0,Math.sin(x),  Math.cos(x),0],
        [0,0,0,1],
      ]);
      const ry = math.matrix([
        [Math.cos(y),0,Math.sin(y),0],
        [0,1,0,0],
        [-Math.sin(y),0,Math.cos(y),0],
        [0,0,0,1],
      ]);
      const rz = math.matrix([
        [Math.cos(z), -Math.sin(z),0,0],
        [Math.sin(z),  Math.cos(z),0,0],
        [0,0,1,0],
        [0,0,0,1],
      ]);
      M = math.multiply(M, rx, ry, rz);
    }
    // scale
    if (tr.scale) {
      const { x=1, y=1, z=1 } = tr.scale;
      const s = math.matrix([
        [x,0,0,0],
        [0,y,0,0],
        [0,0,z,0],
        [0,0,0,1],
      ]);
      M = math.multiply(M, s);
    }
    // translation
    if (tr.translation) {
      const { x=0, y=0, z=0 } = tr.translation;
      const tMat = math.matrix([
        [1,0,0,x],
        [0,1,0,y],
        [0,0,1,z],
        [0,0,0,1],
      ]);
      M = math.multiply(M, tMat);
    }
    return M;
  }

  // update oscillator each frame
  updateOscillator(dt) {
    this.oscillator.update(dt);
  }
  getOscillatorValue() {
    return this.oscillator.getAmplitudeValue();
  }
}
