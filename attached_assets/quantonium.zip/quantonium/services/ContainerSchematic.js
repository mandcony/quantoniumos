// components/ContainerSchematic.js
import React from 'react';
import { View, Text } from 'react-native';
import Svg, { Polygon, Circle } from 'react-native-svg';

export default function ContainerSchematic({ container, size = 200 }) {
  if (!container?.vertices?.length) {
    return <Text>No vertices</Text>;
  }

  // This code assumes vertices are 2D (x,y). If your data is (x,y,z),
  // you can do a projection or just ignore z for the schematic.
  let minX = Infinity, maxX = -Infinity;
  let minY = Infinity, maxY = -Infinity;
  container.vertices.forEach(([x, y]) => {
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;
  });

  const width = maxX - minX || 1;
  const height = maxY - minY || 1;
  const pad = 10;

  // Build an SVG polygon "points" string
  const pointsStr = container.vertices
    .map(([x, y]) => {
      const px = ((x - minX) / width) * (size - 2 * pad) + pad;
      const py = ((y - minY) / height) * (size - 2 * pad) + pad;
      return `${px},${py}`;
    })
    .join(' ');

    return (
        <View>
            <Svg width={size} height={size} style={{ backgroundColor: '#eee' }}>
                <Polygon
                    points={pointsStr}
                    fill="rgba(0,200,0,0.3)"
                    stroke="green"
                    strokeWidth="2"
                />
                {/* circles for each vertex */}
                {container.vertices.map(([x, y], idx) => {
                    const px = ((x - minX) / width) * (size - 2 * pad) + pad;
                    const py = ((y - minY) / height) * (size - 2 * pad) + pad;
                    return (
                        <Circle key={idx} cx={px} cy={py} r={4} fill="red" />
                    );
                })}
            </Svg>
        </View>
    );
}