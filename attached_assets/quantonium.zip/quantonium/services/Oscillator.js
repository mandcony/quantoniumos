// Oscillator.js
// Contains functions for encoding and decoding data to and from the system
export default class Oscillator {
  constructor(frequency = 1, amplitude = 0.1, phase = 0) {
    this.frequency = frequency;
    this.amplitude = amplitude;
    this.phase = phase;
    this.time = 0;
  }

  update(deltaTime) {
    this.time += deltaTime;
  }

  getAmplitudeValue() {
    return this.amplitude * Math.sin(2 * Math.PI * this.frequency * this.time + this.phase);
  }

  setFrequency(freq) {
    this.frequency = freq;
  }

  setAmplitude(amp) {
    this.amplitude = amp;
  }

  setPhase(ph) {
    this.phase = ph;
  }
    encodeValue(value) {
    // Ensure the value is within the safe range [0, 255]
    const safeValue = Math.max(0, Math.min(255, value));

    // Scale the value to fit within the oscillator's property ranges
    this.frequency = 0.5 + (safeValue / 255) * 4.5; // Frequency: [0.5, 5]
    this.amplitude = 0.1 + (safeValue / 255) * 0.9; // Amplitude: [0.1, 1]
    this.phase = (safeValue / 255) * 2 * Math.PI;    // Phase: [0, 2*PI]
  }

  decodeValue() {
    // Reverse the scaling to get the original value
    const frequencyScale = (this.frequency - 0.5) / 4.5;
    const amplitudeScale = (this.amplitude - 0.1) / 0.9;
    const phaseScale = this.phase / (2 * Math.PI);

    // Combine the scales and round to get the decoded value
    const combinedScale = (frequencyScale + amplitudeScale + phaseScale) / 3;
    return Math.round(combinedScale * 255);
  }
}