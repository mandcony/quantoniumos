// OscillatorChartSVGCharts.js
import React, { useState, useEffect, useRef } from 'react';
import { View, Text } from 'react-native';
import { LineChart, Grid } from 'react-native-svg-charts';

export default function OscillatorChartSVGCharts({ oscillator }) {
  const [data, setData] = useState([]);
  const lastTimeRef = useRef(Date.now());

  useEffect(() => {
    if (!oscillator) return;

    let frameId;
    const animate = () => {
      const now = Date.now();
      const dt = (now - lastTimeRef.current) / 1000;
      lastTimeRef.current = now;

      oscillator.update(dt);

      setData(prev => {
        const newVal = oscillator.getAmplitudeValue();
        // keep last 50
        return [...prev.slice(-49), newVal];
      });

      frameId = requestAnimationFrame(animate);
    };
    frameId = requestAnimationFrame(animate);

    return () => {
      if (frameId) cancelAnimationFrame(frameId);
    };
  }, [oscillator]);

  if (!oscillator) {
    return <Text>No oscillator found</Text>;
  }

  if (data.length < 2) {
    return <Text>Gathering data...</Text>;
  }

  return (
    <View style={{ height: 200 }}>
      <LineChart
        style={{ flex: 1 }}
        data={data}
        svg={{ stroke: 'rgb(134, 65, 244)' }}
      >
        <Grid />
      </LineChart>
    </View>
  );
}
