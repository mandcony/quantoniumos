// components/AmplitudeHeatmap.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function AmplitudeHeatmap({ amplitudes = [] }) {
  const extractMagnitude = (ampString) => {
    const match = ampString.match(/[-+]?[0-9]*\.?[0-9]+/);
    return match ? Math.min(Math.abs(parseFloat(match[0])), 1) : 0;
  };

  return (
    <View style={styles.container}>
      {amplitudes.map((amp, idx) => {
        const mag = extractMagnitude(amp);
        // Just map [0..1] to hue [0..240]
        const hue = mag * 240;
        return (
          <View
            key={idx}
            style={[
              styles.ampBox,
              { backgroundColor: `hsl(${hue}, 80%, 60%)` }
            ]}
          >
            <Text style={styles.ampText}>Idx {idx}</Text>
            <Text style={styles.ampText}>{amp}</Text>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center'
  },
  ampBox: {
    width: 70,
    height: 50,
    margin: 2,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4
  },
  ampText: {
    color: '#fff',
    fontSize: 10
  }
});
