// examples/simpleAlgorithm.js
import GeometricContainer from '../GeometricContainer';
import VibrationalEngine from '../VibrationalEngine';

const runSimpleAlgorithm = () => {
      console.log("Starting Algorithm");
    // Create containers
    const container1 = new GeometricContainer('sphere', 5, [0, 0, 0]);
    const container2 = new GeometricContainer('torus', 5, [10, 0, 0]);

    // Create Vibrational Engine
  const engine = new VibrationalEngine();

     // Set vibrations to trigger an interaction.
      engine.applyVibration(container1, 10, 1);
       engine.applyVibration(container2, 20, 1);


    // TODO: Implement more complex behavior and more algorithms.
    console.log("Algorithm Complete");
};

runSimpleAlgorithm();