// tests/linearRegion.test.js
import LinearRegion from '../LinearRegion';

describe('LinearRegion', () => {
    it('should create a linear region with correct properties', () => {
        const region = new LinearRegion({ rule: 'test' }, [1, 2, 3], { mass: 10 });
        expect(region.rules).toEqual({ rule: 'test' });
        expect(region.data).toEqual([1, 2, 3]);
         expect(region.physicsRules).toEqual({ mass: 10 });
    });
    it('should create an empty region if the parameters are not specified', ()=>{
        const region = new LinearRegion();
        expect(region.rules).toEqual(undefined);
        expect(region.data).toEqual(undefined);
        expect(region.physicsRules).toEqual(undefined);
    })
});