// tests/geometricContainer.test.js
import GeometricContainer from '../GeometricContainer';
import LinearRegion from '../LinearRegion';

describe('GeometricContainer', () => {
    it('should create a geometric container with correct properties', () => {
        const container = new GeometricContainer('sphere', 10, [0, 0, 0], { name: 'test' });
        expect(container.type).toBe('sphere');
        expect(container.size).toBe(10);
        expect(container.center).toEqual([0, 0, 0]);
        expect(container.data).toEqual({ name: 'test' });
        expect(container.linearRegions.size).toBe(0);
    });

    it('should add a linear region to the container', () => {
        const container = new GeometricContainer('sphere', 5, [1, 2, 3]);
        container.addLinearRegion('region1', { rule: 'testRule' }, { data: [1, 2, 3] });
        expect(container.linearRegions.size).toBe(1);
        expect(container.getLinearRegion('region1')).toBeInstanceOf(LinearRegion)
        expect(container.getLinearRegion('region1').rules).toEqual({ rule: 'testRule' });
    });

    it('should retrieve a linear region by ID', () => {
           const container = new GeometricContainer('torus', 5, [1, 2, 3]);
        container.addLinearRegion('region1', { rule: 'testRule' }, { data: [1, 2, 3] });
      const region = container.getLinearRegion('region1');
      expect(region).toBeDefined();
      expect(region.rules).toEqual({ rule: 'testRule' });
     });

    it('should throw an error when adding a duplicate linear region id', () => {
          const container = new GeometricContainer('torus', 5, [1, 2, 3]);
      container.addLinearRegion('region1', { rule: 'testRule' }, { data: [1, 2, 3] });
      expect(() => {
          container.addLinearRegion('region1', { rule: 'testRule' }, { data: [1, 2, 3] });
      }).toThrowError("Linear region with ID 'region1' already exists.");
     });
   it('should check if a region exists or not', ()=>{
           const container = new GeometricContainer('torus', 5, [1, 2, 3]);
          container.addLinearRegion('region1', { rule: 'testRule' }, { data: [1, 2, 3] });
       expect(container.hasLinearRegion('region1')).toBeTruthy();
          expect(container.hasLinearRegion('region2')).toBeFalsy();
   });
    it('should delete a linear region by ID', () => {
         const container = new GeometricContainer('torus', 5, [1, 2, 3]);
        container.addLinearRegion('region1', { rule: 'testRule' }, { data: [1, 2, 3] });
        container.deleteLinearRegion('region1');
       expect(container.hasLinearRegion('region1')).toBeFalsy();
        expect(container.linearRegions.size).toBe(0);

   });
    it('should return all linear regions', ()=>{
          const container = new GeometricContainer('torus', 5, [1, 2, 3]);
      container.addLinearRegion('region1', { rule: 'testRule1' }, { data: [1, 2, 3] });
          container.addLinearRegion('region2', { rule: 'testRule2' }, { data: [1, 2, 3] });
       const regions = container.getLinearRegions();
       expect(regions.length).toBe(2);
        expect(regions[0]).toBeInstanceOf(LinearRegion);
      expect(regions[0].rules).toEqual({ rule: 'testRule1' });
        expect(regions[1].rules).toEqual({ rule: 'testRule2' });

    });

    it('should set and get the vibration object correctly', ()=>{
         const container = new GeometricContainer('torus', 5, [1, 2, 3]);
        const vibration = {frequency: 10, amplitude: 1};
     container.setVibration(vibration);
        expect(container.getVibration()).toEqual(vibration);

    });

});