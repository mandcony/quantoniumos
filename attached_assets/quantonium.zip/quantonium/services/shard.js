// services/Shard.js
import { SimplifiedBloomFilter, hash1, hash2 } from './SimplifiedBloomFilter';

export default class Shard {
  constructor(containers) {
    this.containers = containers;
    this.bloom = this._buildBloom(containers);
  }

  _buildBloom(containers) {
    const bf = new SimplifiedBloomFilter(256, [hash1, hash2]);
    for (let c of containers) {
      if (c.resonantFrequencies && c.resonantFrequencies.length > 0) {
        bf.add(c.resonantFrequencies[0]);
      }
    }
    return bf;
  }

  search(targetFreq, threshold = 0.1) {
    // Quick check with the bloom filter first
    if (!this.bloom.test(targetFreq)) {
      return [];
    }
    // Then do a thorough check
    return this.containers.filter(c => {
      if (!c.resonantFrequencies || c.resonantFrequencies.length === 0) {
        return false;
      }
      return Math.abs(c.resonantFrequencies[0] - targetFreq) < threshold;
    });
  }
}
