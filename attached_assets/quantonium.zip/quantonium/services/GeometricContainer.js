// GeometricContainer.js
import * as math from 'mathjs';
import Oscillator from './Oscillator';

// Simple hash function (you can use a more robust one)
function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = (hash << 5) - hash + char;
        hash &= hash; // Convert to 32bit integer
    }
    return Math.abs(hash);
}

export default class GeometricContainer {
    constructor(id, vertices, transformations = [], materialProps = {}) {
        this.id = id;
        this.vertices = vertices;
        this.transformations = transformations;
        this.linearRegions = [];
        this.resonantFrequencies = [];
        this.data = null;
        this.material = {
            youngsModulus: materialProps.youngsModulus || 1e9,
            density: materialProps.density || 2700,
        };
        this.oscillator = new Oscillator(1, 0.1, 0); // example default
        this.bendAmount = 0; // New property
        this.internalVibration = 0; // New property for internal vibration
        this.encodedFrequency = 0; // Add this line
        this.vertexOffsets = []; // NEW
    }

    encodeData(data) {
        this.data = data; // Store the original data
        this.encodedFrequency = this.calculateEncodedFrequency(data); // Also calculate and store frequency
        this.vertexOffsets = this.createVertexOffsets(data); // NEW
    }

    getData() {
        return this.data;
    }

    // Create Vertex Offsets based on Data
    createVertexOffsets(data) {
        const numVertices = this.vertices.length;
        const offsets = [];
        for (let i = 0; i < numVertices; i++) {
            const charCode = data.charCodeAt(i % data.length); // Cycle through input data
            const offsetScale = 0.02; // Limit offset magnitude
            const xOffset = (charCode % 5 - 2) * offsetScale; // -2 to 2
            const yOffset = (charCode % 7 - 3) * offsetScale; // -3 to 3
            const zOffset = (charCode % 3 - 1) * offsetScale;
            offsets.push([xOffset, yOffset, zOffset]);
        }
        return offsets;
    }

    calculateEncodedFrequency(data) { //New method
        const hash = simpleHash(data);
        // Scale the hash to a reasonable frequency range (e.g., 100-500 Hz)
        const minFreq = 100;
        const maxFreq = 500;
        const scaledFrequency = minFreq + (hash % (maxFreq - minFreq));
        return scaledFrequency;
    }

    addLinearRegion(region) {
        this.linearRegions.push(region);
    }

    calculateResonantFrequencies(dampFactor = 0.1) {
        const out = [];
        for (let r of this.linearRegions) {
            if (r.averageLength > 0) {
                const freq = Math.sqrt(
                    this.material.youngsModulus / (this.material.density * r.averageLength)
                ) * (1 - dampFactor);
                out.push(freq);
            } else {
                out.push(0);
            }
        }
        out.push(this.encodedFrequency)
        this.resonantFrequencies = out;
        return out;
    }

    checkResonance(freq, threshold = 0.1) {
        for (let r of this.resonantFrequencies) {
            if (Math.abs(r - freq) <= threshold) return true;
        }
        return false;
    }

    setBendAmount(bend) {
        this.bendAmount = bend;
    }

    setInternalVibration(vibration) {
        this.internalVibration = vibration;
    }

     applyAllTransformations(quantumState) { // Added quantumState argument
        let newVertices = [...this.vertices]
        newVertices = this._applyVertexOffsets(newVertices) // Apply vertex offsets
         newVertices = this._applyBend(newVertices)
        newVertices = this._applyInternalVibration(newVertices, this.encodedFrequency) //Included the encodedFrequency so we would be able to use it.
          //Added function to adjust based on the quantum state
         newVertices = this._adjustVerticesWithQuantumState(newVertices, quantumState);
        let mat = math.identity(4);
        for (let t of this.transformations) {
            mat = math.multiply(mat, this._buildTransformMatrix(t));
        }
          this.vertices = newVertices.map(([x, y, z]) => {
            const vect = math.matrix([x, y, z, 1]);
              const result = math.multiply(mat, vect).toArray();
              return result.slice(0, 3);
          });
    }

    // Apply Vertex Offsets
    _applyVertexOffsets(vertices) {
        return vertices.map(([x, y, z], i) => {
            const [xOffset, yOffset, zOffset] = this.vertexOffsets[i];
            return [x + xOffset, y + yOffset, z + zOffset];
        });
    }

    _applyBend(vertices) {
        const midPoint = vertices.reduce((sum, [x, y, z]) => [sum[0] + x, sum[1] + y, sum[2] + z], [0, 0, 0]).map(x => x / vertices.length);

        return vertices.map(([x, y, z]) => {
            const dist = Math.sqrt((x - midPoint[0]) ** 2 + (y - midPoint[1]) ** 2);
            return [x, y + Math.sin(dist) * this.bendAmount, z]
        })

    }
     _applyInternalVibration(vertices, encodedFrequency) {
        const midPoint = vertices.reduce((sum, [x, y, z]) => [sum[0] + x, sum[1] + y, sum[2] + z], [0, 0, 0]).map(x => x / vertices.length);

        return vertices.map(([x, y, z]) => {
            const dist = Math.sqrt((x - midPoint[0]) ** 2 + (y - midPoint[1]) ** 2);
            return [x + Math.cos(dist * this.internalVibration * encodedFrequency) * 0.05, y + Math.sin(dist * this.internalVibration * encodedFrequency) * 0.05, z]
        })

    }
     _adjustVerticesWithQuantumState(vertices, quantumState) {
         if (!quantumState) return vertices
        const adjustmentFactor = parseFloat(quantumState[0]) || 1;
        return vertices.map(([x, y, z]) => [x * adjustmentFactor, y * adjustmentFactor, z]);
     }
     updateVertices(newVertices) {
      this.vertices = newVertices;
    }
     createCrescentVertices(radius, thickness, numPoints = 32) {
       const vertices = [];
       for (let i = 0; i < numPoints; i++) {
         const angle = (i / numPoints) * 2 * Math.PI;
         const x = radius * Math.cos(angle) + (radius - thickness/2);
         const y = radius * Math.sin(angle)
         const z = 0;
          vertices.push([x, y, z]);
         }
       for (let i = numPoints -1; i >= 0; i--){
              const angle = (i / numPoints) * 2 * Math.PI;
            const x = (radius - thickness) * Math.cos(angle) + (radius - thickness/2)
          const y = (radius - thickness) * Math.sin(angle);
           const z = 0;
            vertices.push([x,y,z]);
          }
        return vertices
    }


    _buildTransformMatrix(tr) {
        let M = math.identity(4);

        // rotation
        if (tr.rotation) {
            const { x = 0, y = 0, z = 0 } = tr.rotation;
            const rx = math.matrix([
                [1, 0, 0, 0],
                [0, Math.cos(x), -Math.sin(x), 0],
                [0, Math.sin(x), Math.cos(x), 0],
                [0, 0, 0, 1],
            ]);
            const ry = math.matrix([
                [Math.cos(y), 0, Math.sin(y), 0],
                [0, 1, 0, 0],
                [-Math.sin(y), 0, Math.cos(y), 0],
                [0, 0, 0, 1],
            ]);
            const rz = math.matrix([
                [Math.cos(z), -Math.sin(z), 0, 0],
                [Math.sin(z), Math.cos(z), 0, 0],
                [0, 0, 1, 0],
                [0, 0, 0, 1],
            ]);
            M = math.multiply(M, rx, ry, rz);
        }

        // scale
        if (tr.scale) {
            const { x = 1, y = 1, z = 1 } = tr.scale;
            const s = math.matrix([
                [x, 0, 0, 0],
                [0, y, 0, 0],
                [0, 0, z, 0],
                [0, 0, 0, 1],
            ]);
            M = math.multiply(M, s);
        }

        // translation
        if (tr.translation) {
            const { x = 0, y = 0, z = 0 } = tr.translation;
            const tMat = math.matrix([
                [1, 0, 0, x],
                [0, 1, 0, y],
                [0, 0, 1, z],
                [0, 0, 0, 1],
            ]);
            M = math.multiply(M, tMat);
        }

        return M;
    }

    // oscillator time stepping
    updateOscillator(dt) {
        this.oscillator.update(dt);
    }

    getOscillatorValue() {
        return this.oscillator.getAmplitudeValue();
    }
}